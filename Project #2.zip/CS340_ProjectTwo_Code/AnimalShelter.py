from pymongo import MongoClient


class AnimalShelter:
    """CRUD operations for the AAC animal collection."""

    def __init__(self, username="aacuser", password="Ralls"):
        """Initialize connection to the AAC MongoDB database."""

        USER = username
        PASS = password
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        self.client = MongoClient(
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin"
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a document into the collection."""
        try:
            if isinstance(data, dict) and data:
                result = self.collection.insert_one(data)
                return result.acknowledged
            return False

        except Exception as error:
            print("Create error:", error)
            return False

    def read(self, search_data):
        """Return documents matching the search criteria."""
        try:
            if isinstance(search_data, dict):
                results = self.collection.find(
                    search_data,
                    {"_id": False}
                )
                return list(results)
            return []

        except Exception as error:
            print("Read error:", error)
            return []

    def update(self, search_data, update_data):
        """Update documents matching the search criteria."""
        try:
            if isinstance(search_data, dict) and isinstance(update_data, dict):
                result = self.collection.update_many(
                    search_data,
                    {"$set": update_data}
                )
                return result.modified_count
            return 0

        except Exception as error:
            print("Update error:", error)
            return 0

    def delete(self, delete_data):
        """Delete documents matching the search criteria."""
        try:
            if isinstance(delete_data, dict):
                result = self.collection.delete_many(delete_data)
                return result.deleted_count
            return 0

        except Exception as error:
            print("Delete error:", error)
            return 0